"""Generate a Pyrogram STRING_SESSION without creating a .session file."""

from pyrogram import Client

from cfg import API_HASH, API_ID


def main() -> None:
    app = Client(
        "session_generator",
        api_id=API_ID,
        api_hash=API_HASH,
        in_memory=True,
    )

    try:
        app.start()
        print("\nСкопируйте строку ниже в STRING_SESSION в файле .env:\n")
        print(app.export_session_string())
    finally:
        if app.is_connected:
            app.stop()


if __name__ == "__main__":
    main()
